import Fastify from "fastify";
import fastifyCookie from "@fastify/cookie";
import fastifyJwt from "@fastify/jwt";
import { Pool } from "pg";
import fetch from "node-fetch";
import * as dotenv from "dotenv";

dotenv.config();

const app = Fastify({ logger: true });
const db = new Pool({ connectionString: process.env.DATABASE_URL });

// ── Plugins ───────────────────────────────────────────────────────────────────

await app.register(fastifyCookie);
await app.register(fastifyJwt, { secret: process.env.JWT_SECRET! });

// ── DB Setup ──────────────────────────────────────────────────────────────────

await db.query(`
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT NOT NULL,
        avatar TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS settings (
        user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
        data JSONB NOT NULL DEFAULT '{}',
        updated_at TIMESTAMPTZ DEFAULT NOW()
    );
`);

// ── Auth Middleware ───────────────────────────────────────────────────────────

async function authenticate(request: any, reply: any) {
    try {
        await request.jwtVerify();
    } catch {
        reply.status(401).send({ error: "Unauthorized" });
    }
}

// ── Routes ────────────────────────────────────────────────────────────────────

// Health check
app.get("/", async () => ({ status: "ok", name: "RMS Cloud Backend" }));

// Start Discord OAuth2 login
app.get("/auth/discord", async (request, reply) => {
    const params = new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID!,
        redirect_uri: process.env.DISCORD_REDIRECT_URI!,
        response_type: "code",
        scope: "identify",
    });
    reply.redirect(`https://discord.com/oauth2/authorize?${params}`);
});

// Discord OAuth2 callback
app.get<{ Querystring: { code?: string } }>("/auth/callback", async (request, reply) => {
    const { code } = request.query;

    if (!code) return reply.status(400).send({ error: "Missing code" });

    // Exchange code for token
    const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
            client_id: process.env.DISCORD_CLIENT_ID!,
            client_secret: process.env.DISCORD_CLIENT_SECRET!,
            grant_type: "authorization_code",
            code,
            redirect_uri: process.env.DISCORD_REDIRECT_URI!,
        }),
    });

    const tokenData = await tokenRes.json() as any;
    if (!tokenData.access_token) return reply.status(400).send({ error: "OAuth failed" });

    // Get user info from Discord
    const userRes = await fetch("https://discord.com/api/users/@me", {
        headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });

    const user = await userRes.json() as any;

    // Save user to DB
    await db.query(`
        INSERT INTO users (id, username, avatar)
        VALUES ($1, $2, $3)
        ON CONFLICT (id) DO UPDATE SET username = $2, avatar = $3
    `, [user.id, user.username, user.avatar]);

    // Sign JWT
    const jwt = app.jwt.sign({ id: user.id, username: user.username }, { expiresIn: "30d" });

    // Redirect back to RMS with token
    reply.redirect(`rms://auth?token=${jwt}`);
});

// Get current user info
app.get("/user", { preHandler: authenticate }, async (request: any) => {
    const { id } = request.user;
    const result = await db.query("SELECT id, username, avatar FROM users WHERE id = $1", [id]);
    return result.rows[0] ?? null;
});

// Get settings
app.get("/settings", { preHandler: authenticate }, async (request: any) => {
    const { id } = request.user;
    const result = await db.query("SELECT data FROM settings WHERE user_id = $1", [id]);
    return result.rows[0]?.data ?? {};
});

// Upload/update settings
app.put("/settings", { preHandler: authenticate }, async (request: any, reply) => {
    const { id } = request.user;
    const data = request.body;

    if (!data || typeof data !== "object") {
        return reply.status(400).send({ error: "Invalid settings data" });
    }

    await db.query(`
        INSERT INTO settings (user_id, data, updated_at)
        VALUES ($1, $2, NOW())
        ON CONFLICT (user_id) DO UPDATE SET data = $2, updated_at = NOW()
    `, [id, JSON.stringify(data)]);

    return { ok: true };
});

// Delete settings
app.delete("/settings", { preHandler: authenticate }, async (request: any) => {
    const { id } = request.user;
    await db.query("DELETE FROM settings WHERE user_id = $1", [id]);
    return { ok: true };
});

// ── Start ─────────────────────────────────────────────────────────────────────

const port = parseInt(process.env.PORT ?? "8080");
await app.listen({ port, host: "0.0.0.0" });
console.log(`RMS Cloud Backend running on port ${port}`);
