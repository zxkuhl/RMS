@echo off
title RMS Manual Installer
color 0F

echo.
echo  ==========================================
echo        RMS - Discord Client Mod
echo        Manual Installer
echo  ==========================================
echo.

:: Check internet
echo [1/4] Checking internet connection...
ping -n 1 raw.githubusercontent.com >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  ERROR: No internet connection detected.
    echo  Please connect to the internet and try again.
    echo.
    pause
    exit /b 1
)
echo  OK

:: Get latest version from GitHub
echo.
echo [2/4] Fetching latest version...
set "VERSION_URL=https://raw.githubusercontent.com/zxkuhl/RMS/refs/heads/main/version.txt"
set "VERSION_FILE=%TEMP%\rms_version.txt"

powershell -Command "Invoke-WebRequest -Uri '%VERSION_URL%' -OutFile '%VERSION_FILE%' -UseBasicParsing" >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  ERROR: Could not fetch version info from GitHub.
    echo  Check your internet connection and try again.
    echo.
    pause
    exit /b 1
)

set /p RMS_VERSION=<%VERSION_FILE%
set RMS_VERSION=%RMS_VERSION: =%
echo  Latest version: %RMS_VERSION%

:: Download release assets
echo.
echo [3/4] Downloading RMS %RMS_VERSION% files...

set "DIST_DIR=%APPDATA%\RMS\dist"
set "API_URL=https://api.github.com/repos/zxkuhl/RMS/releases/tags/%RMS_VERSION%"
set "ASSETS_FILE=%TEMP%\rms_assets.json"

powershell -Command "Invoke-WebRequest -Uri '%API_URL%' -OutFile '%ASSETS_FILE%' -UseBasicParsing -Headers @{'User-Agent'='RMS-Installer'}" >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  ERROR: Could not fetch release info for version %RMS_VERSION%.
    echo  Make sure the release exists on GitHub.
    echo.
    pause
    exit /b 1
)

:: Create dist folder
if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"

:: Download each asset using PowerShell
powershell -Command ^
    "$json = Get-Content '%ASSETS_FILE%' | ConvertFrom-Json; " ^
    "foreach ($asset in $json.assets) { " ^
    "    Write-Host '  Downloading:' $asset.name; " ^
    "    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile ('%DIST_DIR%\' + $asset.name) -UseBasicParsing " ^
    "}"

if %errorlevel% neq 0 (
    echo.
    echo  ERROR: Failed to download some files.
    echo  Please try again or use the online installer.
    echo.
    pause
    exit /b 1
)

:: Save version
echo %RMS_VERSION%>"%APPDATA%\RMS\dist\version.txt"

echo  Done! Files saved to %DIST_DIR%

:: Run installer
echo.
echo [4/4] Launching RMS Installer...
echo.

if exist "%~dp0RMSInstaller.exe" (
    echo  Starting RMSInstaller.exe...
    echo  Follow the on-screen steps to complete installation.
    echo.
    start "" "%~dp0RMSInstaller.exe"
) else (
    echo  NOTE: RMSInstaller.exe not found next to this script.
    echo  Files have been downloaded to AppData.
    echo  Please run RMSInstaller.exe manually to patch Discord.
    echo.
    pause
)

exit /b 0
