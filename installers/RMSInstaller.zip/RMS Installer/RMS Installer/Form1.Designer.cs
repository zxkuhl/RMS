﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace RMS_Installer
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panelTop = new Panel();
            labelLogo = new Label();
            labelClose = new Label();
            panelLegal = new Panel();
            labelLegalTitle = new Label();
            labelLegalSub = new Label();
            richBoxLegal = new RichTextBox();
            checkAccept = new CheckBox();
            labelDisclaimer = new Label();
            btnProceed = new Button();
            panelMain = new Panel();
            labelTitle = new Label();
            labelSubtitle = new Label();
            panelDivider = new Panel();
            panelInfo = new Panel();
            labelInfo = new Label();
            btnInstall = new Button();
            btnUninstall = new Button();
            btnReinstall = new Button();
            progressBar = new ProgressBar();
            labelStatus = new Label();
            richBoxLog = new RichTextBox();
            panelTop.SuspendLayout();
            panelLegal.SuspendLayout();
            panelMain.SuspendLayout();
            panelInfo.SuspendLayout();
            SuspendLayout();
            // 
            // panelTop
            // 
            panelTop.BackColor = Color.FromArgb(18, 18, 30);
            panelTop.Controls.Add(labelLogo);
            panelTop.Controls.Add(labelClose);
            panelTop.Dock = DockStyle.Top;
            panelTop.Location = new Point(0, 0);
            panelTop.Name = "panelTop";
            panelTop.Size = new Size(800, 48);
            panelTop.TabIndex = 0;
            // 
            // labelLogo
            // 
            labelLogo.AutoSize = true;
            labelLogo.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            labelLogo.ForeColor = Color.FromArgb(220, 220, 255);
            labelLogo.Location = new Point(16, 12);
            labelLogo.Name = "labelLogo";
            labelLogo.Size = new Size(73, 25);
            labelLogo.TabIndex = 0;
            labelLogo.Text = "◈ RMS";
            // 
            // labelClose
            // 
            labelClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            labelClose.AutoSize = true;
            labelClose.Cursor = Cursors.Hand;
            labelClose.Font = new Font("Segoe UI", 10F);
            labelClose.ForeColor = Color.FromArgb(120, 120, 160);
            labelClose.Location = new Point(1376, 14);
            labelClose.Name = "labelClose";
            labelClose.Size = new Size(20, 19);
            labelClose.TabIndex = 1;
            labelClose.Text = "✕";
            // 
            // panelLegal
            // 
            panelLegal.BackColor = Color.FromArgb(10, 10, 18);
            panelLegal.Controls.Add(labelLegalTitle);
            panelLegal.Controls.Add(labelLegalSub);
            panelLegal.Controls.Add(richBoxLegal);
            panelLegal.Controls.Add(checkAccept);
            panelLegal.Controls.Add(labelDisclaimer);
            panelLegal.Controls.Add(btnProceed);
            panelLegal.Location = new Point(0, 48);
            panelLegal.Name = "panelLegal";
            panelLegal.Size = new Size(800, 402);
            panelLegal.TabIndex = 1;
            // 
            // labelLegalTitle
            // 
            labelLegalTitle.AutoSize = true;
            labelLegalTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            labelLegalTitle.ForeColor = Color.FromArgb(220, 220, 255);
            labelLegalTitle.Location = new Point(28, 24);
            labelLegalTitle.Name = "labelLegalTitle";
            labelLegalTitle.Size = new Size(180, 25);
            labelLegalTitle.TabIndex = 0;
            labelLegalTitle.Text = "License Agreement";
            // 
            // labelLegalSub
            // 
            labelLegalSub.AutoSize = true;
            labelLegalSub.ForeColor = Color.FromArgb(120, 120, 160);
            labelLegalSub.Location = new Point(28, 54);
            labelLegalSub.Name = "labelLegalSub";
            labelLegalSub.Size = new Size(296, 15);
            labelLegalSub.TabIndex = 1;
            labelLegalSub.Text = "Please read the following license before installing RMS.";
            // 
            // richBoxLegal
            // 
            richBoxLegal.BackColor = Color.FromArgb(18, 18, 30);
            richBoxLegal.BorderStyle = BorderStyle.None;
            richBoxLegal.Font = new Font("Consolas", 8.5F);
            richBoxLegal.ForeColor = Color.FromArgb(120, 120, 160);
            richBoxLegal.Location = new Point(28, 80);
            richBoxLegal.Name = "richBoxLegal";
            richBoxLegal.ReadOnly = true;
            richBoxLegal.ScrollBars = RichTextBoxScrollBars.Vertical;
            richBoxLegal.Size = new Size(744, 220);
            richBoxLegal.TabIndex = 2;
            richBoxLegal.Text = "";
            // 
            // checkAccept
            // 
            checkAccept.AutoSize = true;
            checkAccept.Cursor = Cursors.Hand;
            checkAccept.ForeColor = Color.FromArgb(220, 220, 255);
            checkAccept.Location = new Point(28, 316);
            checkAccept.Name = "checkAccept";
            checkAccept.Size = new Size(271, 19);
            checkAccept.TabIndex = 3;
            checkAccept.Text = "I have read and agree to the license agreement";
            // 
            // labelDisclaimer
            // 
            labelDisclaimer.AutoSize = true;
            labelDisclaimer.Font = new Font("Segoe UI", 8.5F);
            labelDisclaimer.ForeColor = Color.FromArgb(100, 100, 140);
            labelDisclaimer.Location = new Point(28, 344);
            labelDisclaimer.Name = "labelDisclaimer";
            labelDisclaimer.Size = new Size(315, 15);
            labelDisclaimer.TabIndex = 4;
            labelDisclaimer.Text = "RMS is not affiliated with Discord Inc. Use at your own risk.";
            // 
            // btnProceed
            // 
            btnProceed.BackColor = Color.FromArgb(88, 101, 242);
            btnProceed.Cursor = Cursors.Hand;
            btnProceed.Enabled = false;
            btnProceed.FlatAppearance.BorderSize = 0;
            btnProceed.FlatStyle = FlatStyle.Flat;
            btnProceed.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnProceed.ForeColor = Color.White;
            btnProceed.Location = new Point(644, 366);
            btnProceed.Name = "btnProceed";
            btnProceed.Size = new Size(128, 36);
            btnProceed.TabIndex = 5;
            btnProceed.Text = "Continue →";
            btnProceed.UseVisualStyleBackColor = false;
            // 
            // panelMain
            // 
            panelMain.BackColor = Color.FromArgb(10, 10, 18);
            panelMain.Controls.Add(labelTitle);
            panelMain.Controls.Add(labelSubtitle);
            panelMain.Controls.Add(panelDivider);
            panelMain.Controls.Add(panelInfo);
            panelMain.Controls.Add(btnInstall);
            panelMain.Controls.Add(btnUninstall);
            panelMain.Controls.Add(btnReinstall);
            panelMain.Controls.Add(progressBar);
            panelMain.Controls.Add(labelStatus);
            panelMain.Controls.Add(richBoxLog);
            panelMain.Location = new Point(0, 48);
            panelMain.Name = "panelMain";
            panelMain.Size = new Size(800, 402);
            panelMain.TabIndex = 2;
            panelMain.Visible = false;
            // 
            // labelTitle
            // 
            labelTitle.AutoSize = true;
            labelTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            labelTitle.ForeColor = Color.FromArgb(220, 220, 255);
            labelTitle.Location = new Point(28, 24);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new Size(188, 37);
            labelTitle.TabIndex = 0;
            labelTitle.Text = "RMS Installer";
            // 
            // labelSubtitle
            // 
            labelSubtitle.AutoSize = true;
            labelSubtitle.ForeColor = Color.FromArgb(120, 120, 160);
            labelSubtitle.Location = new Point(30, 62);
            labelSubtitle.Name = "labelSubtitle";
            labelSubtitle.Size = new Size(150, 15);
            labelSubtitle.TabIndex = 1;
            labelSubtitle.Text = "Discord client modification";
            // 
            // panelDivider
            // 
            panelDivider.BackColor = Color.FromArgb(40, 40, 70);
            panelDivider.Location = new Point(28, 88);
            panelDivider.Name = "panelDivider";
            panelDivider.Size = new Size(744, 1);
            panelDivider.TabIndex = 2;
            // 
            // panelInfo
            // 
            panelInfo.BackColor = Color.FromArgb(18, 18, 30);
            panelInfo.Controls.Add(labelInfo);
            panelInfo.Location = new Point(28, 100);
            panelInfo.Name = "panelInfo";
            panelInfo.Size = new Size(744, 50);
            panelInfo.TabIndex = 3;
            // 
            // labelInfo
            // 
            labelInfo.Dock = DockStyle.Fill;
            labelInfo.Font = new Font("Consolas", 8.5F);
            labelInfo.ForeColor = Color.FromArgb(120, 120, 160);
            labelInfo.Location = new Point(0, 0);
            labelInfo.Name = "labelInfo";
            labelInfo.Padding = new Padding(10, 8, 0, 0);
            labelInfo.Size = new Size(744, 50);
            labelInfo.TabIndex = 0;
            labelInfo.Text = "Install: %AppData%\\RMS       Discord: %LocalAppData%\\Discord";
            // 
            // btnInstall
            // 
            btnInstall.BackColor = Color.FromArgb(88, 101, 242);
            btnInstall.Cursor = Cursors.Hand;
            btnInstall.FlatAppearance.BorderSize = 0;
            btnInstall.FlatStyle = FlatStyle.Flat;
            btnInstall.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnInstall.ForeColor = Color.White;
            btnInstall.Location = new Point(28, 164);
            btnInstall.Name = "btnInstall";
            btnInstall.Size = new Size(200, 44);
            btnInstall.TabIndex = 4;
            btnInstall.Text = "⬇  Install RMS";
            btnInstall.UseVisualStyleBackColor = false;
            // 
            // btnUninstall
            // 
            btnUninstall.BackColor = Color.FromArgb(40, 40, 60);
            btnUninstall.Cursor = Cursors.Hand;
            btnUninstall.FlatAppearance.BorderSize = 0;
            btnUninstall.FlatStyle = FlatStyle.Flat;
            btnUninstall.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnUninstall.ForeColor = Color.FromArgb(200, 200, 220);
            btnUninstall.Location = new Point(240, 164);
            btnUninstall.Name = "btnUninstall";
            btnUninstall.Size = new Size(140, 44);
            btnUninstall.TabIndex = 5;
            btnUninstall.Text = "✕  Uninstall";
            btnUninstall.UseVisualStyleBackColor = false;
            // 
            // btnReinstall
            // 
            btnReinstall.BackColor = Color.FromArgb(40, 40, 60);
            btnReinstall.Cursor = Cursors.Hand;
            btnReinstall.FlatAppearance.BorderSize = 0;
            btnReinstall.FlatStyle = FlatStyle.Flat;
            btnReinstall.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnReinstall.ForeColor = Color.FromArgb(200, 200, 220);
            btnReinstall.Location = new Point(392, 164);
            btnReinstall.Name = "btnReinstall";
            btnReinstall.Size = new Size(140, 44);
            btnReinstall.TabIndex = 6;
            btnReinstall.Text = "↺  Reinstall";
            btnReinstall.UseVisualStyleBackColor = false;
            // 
            // progressBar
            // 
            progressBar.Location = new Point(28, 220);
            progressBar.Name = "progressBar";
            progressBar.Size = new Size(744, 6);
            progressBar.Style = ProgressBarStyle.Continuous;
            progressBar.TabIndex = 7;
            progressBar.Visible = false;
            // 
            // labelStatus
            // 
            labelStatus.AutoSize = true;
            labelStatus.Font = new Font("Segoe UI", 9F);
            labelStatus.ForeColor = Color.FromArgb(120, 120, 160);
            labelStatus.Location = new Point(28, 234);
            labelStatus.Name = "labelStatus";
            labelStatus.Size = new Size(42, 15);
            labelStatus.TabIndex = 8;
            labelStatus.Text = "Ready.";
            // 
            // richBoxLog
            // 
            richBoxLog.BackColor = Color.FromArgb(18, 18, 30);
            richBoxLog.BorderStyle = BorderStyle.None;
            richBoxLog.Font = new Font("Consolas", 8.5F);
            richBoxLog.ForeColor = Color.FromArgb(120, 120, 160);
            richBoxLog.Location = new Point(28, 256);
            richBoxLog.Name = "richBoxLog";
            richBoxLog.ReadOnly = true;
            richBoxLog.ScrollBars = RichTextBoxScrollBars.Vertical;
            richBoxLog.Size = new Size(744, 134);
            richBoxLog.TabIndex = 9;
            richBoxLog.Text = "";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(10, 10, 18);
            ClientSize = new Size(800, 450);
            Controls.Add(panelTop);
            Controls.Add(panelLegal);
            Controls.Add(panelMain);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "RMS Installer";
            panelTop.ResumeLayout(false);
            panelTop.PerformLayout();
            panelLegal.ResumeLayout(false);
            panelLegal.PerformLayout();
            panelMain.ResumeLayout(false);
            panelMain.PerformLayout();
            panelInfo.ResumeLayout(false);
            ResumeLayout(false);
        }

        // Top bar
        private Panel panelTop;
        private Label labelLogo;
        private Label labelClose;

        // Legal
        private Panel panelLegal;
        private Label labelLegalTitle;
        private Label labelLegalSub;
        private RichTextBox richBoxLegal;
        private CheckBox checkAccept;
        private Label labelDisclaimer;
        private Button btnProceed;

        // Main
        private Panel panelMain;
        private Label labelTitle;
        private Label labelSubtitle;
        private Panel panelDivider;
        private Panel panelInfo;
        private Label labelInfo;
        private Button btnInstall;
        private Button btnUninstall;
        private Button btnReinstall;
        private ProgressBar progressBar;
        private Label labelStatus;
        private RichTextBox richBoxLog;
    }
}