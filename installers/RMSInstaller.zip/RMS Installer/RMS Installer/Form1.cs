using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMS_Installer
{
    partial class Form1 : Form
    {
        static Color ACCENT = Color.FromArgb(88, 101, 242);
        static Color TEXT = Color.FromArgb(220, 220, 255);
        static Color SUBTEXT = Color.FromArgb(120, 120, 160);
        static Color SUCCESS = Color.FromArgb(67, 181, 129);
        static Color DANGER = Color.FromArgb(237, 66, 69);
        static Color WARN = Color.FromArgb(250, 166, 26);

        bool legalAccepted = false;
        string AppDataRMS => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "RMS");
        string DistSource => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dist");

        public Form1()
        {
            InitializeComponent();
            WireEvents();
            richBoxLegal.Text = GetLicenseText();
        }

        void WireEvents()
        {
            // Drag
            bool dragging = false;
            System.Drawing.Point dragStart = System.Drawing.Point.Empty;
            panelTop.MouseDown += (s, e) => { dragging = true; dragStart = e.Location; };
            panelTop.MouseMove += (s, e) => { if (dragging) { var p = PointToScreen(e.Location); Location = new System.Drawing.Point(p.X - dragStart.X, p.Y - dragStart.Y); } };
            panelTop.MouseUp += (s, e) => dragging = false;

            // Close
            labelClose.Click += (s, e) => Application.Exit();
            labelClose.MouseEnter += (s, e) => labelClose.ForeColor = DANGER;
            labelClose.MouseLeave += (s, e) => labelClose.ForeColor = SUBTEXT;

            // Legal
            checkAccept.CheckedChanged += (s, e) => {
                legalAccepted = checkAccept.Checked;
                btnProceed.Enabled = legalAccepted;
                btnProceed.BackColor = legalAccepted ? ACCENT : Color.FromArgb(50, 50, 80);
            };
            btnProceed.Click += (s, e) => { if (legalAccepted) ShowMainScreen(); };

            // Action buttons
            btnInstall.Click += async (s, e) => await RunAction("install");
            btnUninstall.Click += async (s, e) => await RunAction("uninstall");
            btnReinstall.Click += async (s, e) => await RunAction("reinstall");
        }

        void ShowMainScreen() { panelLegal.Visible = false; panelMain.Visible = true; }

        void Log(string msg, Color? color = null)
        {
            if (richBoxLog.InvokeRequired) { richBoxLog.Invoke(new Action(() => Log(msg, color))); return; }
            richBoxLog.SelectionColor = color ?? SUBTEXT;
            richBoxLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}\n");
            richBoxLog.ScrollToCaret();
        }

        void SetStatus(string msg, Color? color = null)
        {
            if (labelStatus.InvokeRequired) { labelStatus.Invoke(new Action(() => SetStatus(msg, color))); return; }
            labelStatus.Text = msg;
            labelStatus.ForeColor = color ?? SUBTEXT;
        }

        void SetProgress(int val)
        {
            if (progressBar.InvokeRequired) { progressBar.Invoke(new Action(() => SetProgress(val))); return; }
            progressBar.Value = Math.Max(0, Math.Min(100, val));
            progressBar.Visible = val > 0 && val < 100;
        }

        void SetButtons(bool enabled)
        {
            if (btnInstall.InvokeRequired) { btnInstall.Invoke(new Action(() => SetButtons(enabled))); return; }
            btnInstall.Enabled = btnUninstall.Enabled = btnReinstall.Enabled = enabled;
        }

        async Task RunAction(string action)
        {
            SetButtons(false);
            try
            {
                switch (action)
                {
                    case "install": await Install(); break;
                    case "uninstall": await Uninstall(); break;
                    case "reinstall": await Uninstall(); await Install(); break;
                }
            }
            catch (Exception ex)
            {
                Log($"Error: {ex.Message}", DANGER);
                SetStatus("Failed.", DANGER);
            }
            SetButtons(true);
            SetProgress(0);
        }

        async Task Install()
        {
            Log("Starting RMS installation...", TEXT);
            SetStatus("Installing...", WARN);
            SetProgress(10);

            if (!Directory.Exists(DistSource))
            {
                Log($"dist/ folder not found next to installer!", DANGER);
                Log($"Expected: {DistSource}", SUBTEXT);
                SetStatus("Failed — dist/ not found.", DANGER);
                return;
            }

            SetProgress(20);
            Log("Copying RMS files to AppData...", SUBTEXT);

            var destDist = Path.Combine(AppDataRMS, "dist");
            Directory.CreateDirectory(destDist);

            var files = Directory.GetFiles(DistSource, "*", SearchOption.AllDirectories);
            int i = 0;
            foreach (var file in files)
            {
                var rel = Path.GetRelativePath(DistSource, file);
                var dest = Path.Combine(destDist, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                File.Copy(file, dest, true);
                Log($"Copied: {rel}", SUBTEXT);
                SetProgress(20 + (int)(60f * ++i / files.Length));
                await Task.Delay(10);
            }

            SetProgress(85);
            Log("Patching Discord...", TEXT);

            string? discordPath = FindDiscord();
            if (discordPath == null)
            {
                Log("Discord not found — files copied but Discord not patched.", WARN);
                SetStatus("Partial install — Discord not found.", WARN);
                SetProgress(0);
                return;
            }

            Log($"Found Discord at: {discordPath}", SUBTEXT);
            bool patched = PatchDiscord(discordPath);
            SetProgress(100);

            if (patched) { Log("RMS installed! Restart Discord.", SUCCESS); SetStatus("Installed! Restart Discord.", SUCCESS); }
            else { Log("Files copied but patch failed. Try running as admin.", WARN); SetStatus("Partial install.", WARN); }
        }

        async Task Uninstall()
        {
            Log("Uninstalling RMS...", TEXT);
            SetStatus("Uninstalling...", WARN);
            SetProgress(20);

            if (Directory.Exists(AppDataRMS)) { Directory.Delete(AppDataRMS, true); Log("Removed AppData\\RMS", SUBTEXT); }

            SetProgress(50);
            string? discordPath = FindDiscord();
            if (discordPath != null) RestoreDiscord(discordPath);

            SetProgress(100);
            await Task.Delay(200);
            Log("RMS uninstalled. Restart Discord.", SUCCESS);
            SetStatus("Uninstalled. Restart Discord.", SUCCESS);
        }

        string? FindDiscord()
        {
            var localApp = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var discordBase = Path.Combine(localApp, "Discord");
            if (!Directory.Exists(discordBase)) return null;
            var appDirs = Directory.GetDirectories(discordBase, "app-*");
            if (appDirs.Length == 0) return null;
            Array.Sort(appDirs);
            return Path.Combine(appDirs[^1], "resources");
        }

        bool PatchDiscord(string resourcesPath)
        {
            try
            {
                var appAsar = Path.Combine(resourcesPath, "app.asar");
                var appAsarBak = Path.Combine(resourcesPath, "_app.asar");
                var appFolder = Path.Combine(resourcesPath, "app");

                if (!File.Exists(appAsar) && Directory.Exists(appFolder))
                {
                    var indexJs = Path.Combine(appFolder, "index.js");
                    if (File.Exists(indexJs))
                    {
                        var content = File.ReadAllText(indexJs);
                        content = System.Text.RegularExpressions.Regex.Replace(content,
                            @"require\(['""].*?patcher\.js['""]\)",
                            $"require('{Path.Combine(AppDataRMS, "dist", "patcher.js").Replace("\\", "\\\\")}')");
                        File.WriteAllText(indexJs, content);
                        Log("Updated existing patch to point to RMS.", SUCCESS);
                        return true;
                    }
                }

                if (File.Exists(appAsar))
                {
                    File.Move(appAsar, appAsarBak);
                    Directory.CreateDirectory(appFolder);
                    File.WriteAllText(Path.Combine(appFolder, "package.json"), "{\"name\":\"rms\",\"main\":\"index.js\"}");

                    var patcherPath = Path.Combine(AppDataRMS, "dist", "patcher.js").Replace("\\", "/");
                    var indexContent =
                        "require.main.path = require.main.path.replace(/[\\\\/]app$/, '') + '\\\\app.asar';\n" +
                        $"require('{patcherPath}');";
                    File.WriteAllText(Path.Combine(appFolder, "index.js"), indexContent);

                    Log("Discord patched successfully.", SUCCESS);
                    return true;
                }

                return false;
            }
            catch (Exception ex) { Log($"Patch error: {ex.Message}", DANGER); return false; }
        }

        void RestoreDiscord(string resourcesPath)
        {
            try
            {
                var appAsar = Path.Combine(resourcesPath, "app.asar");
                var appAsarBak = Path.Combine(resourcesPath, "_app.asar");
                var appFolder = Path.Combine(resourcesPath, "app");
                if (File.Exists(appAsarBak) && !File.Exists(appAsar)) { File.Move(appAsarBak, appAsar); Log("Restored app.asar", SUBTEXT); }
                if (Directory.Exists(appFolder)) { Directory.Delete(appFolder, true); Log("Removed app folder", SUBTEXT); }
            }
            catch (Exception ex) { Log($"Restore error: {ex.Message}", WARN); }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using var pen = new System.Drawing.Pen(Color.FromArgb(50, 50, 90), 1);
            e.Graphics.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
        }

        protected override CreateParams CreateParams
        {
            get { var cp = base.CreateParams; cp.ClassStyle |= 0x20000; return cp; }
        }

        string GetLicenseText() => @"RMS - Discord Client Modification
Copyright (c) 2026 zxkuhl. All rights reserved.

PROPRIETARY SOFTWARE LICENSE

This software and its source code are the exclusive property of zxkuhl.
No part of this software may be copied, modified, merged, distributed,
sublicensed, sold, or used in any commercial or non-commercial product
without the express written permission of zxkuhl.

RESTRICTIONS:
- You may NOT modify, alter, or create derivative works of this software.
- You may NOT redistribute, share, or transfer this software to any
  third party in any form, whether modified or unmodified.
- You may NOT reverse engineer, decompile, or disassemble this software.
- You may NOT use this software or any part of it in your own projects.
- You may NOT claim ownership or authorship of this software.

PERMITTED USE:
- Personal, non-commercial use on your own device only.

DISCLAIMER:
RMS is an unofficial modification for Discord. It is not affiliated
with, endorsed by, or supported by Discord Inc. Use of this software
may violate Discord's Terms of Service. You use this at your own risk.

zxkuhl is not responsible for any account suspensions, bans, data loss,
or any other damages resulting from the use of this software.

By installing RMS you acknowledge that you have read, understood, and
agree to be bound by the terms of this license.";
    }
}